import {ZoteroHost} from './platform.ts';
import {mountManager} from './ui.ts';
import type {ManagerUIOptions} from './ui.ts';
import type {Workspace} from './workspace-contract.ts';
import {createNativeWorkspace} from './workspace.ts';
import type {NativeWorkspace} from './workspace.ts';

type StartupData = { id: string; version: string; rootURI: string; indexLibrary?:boolean };

const HTML = 'http://www.w3.org/1999/xhtml';
const LOCALE = 'smart-tags.ftl';
const MANAGER_URL = 'chrome://smart-tags/content/manager.xhtml';
let workspace: NativeWorkspace | null = null;
let host: ZoteroHost | null = null;
let managerWindow: Window | null = null;
let managerUI: ReturnType<typeof mountManager> | null = null;
let managerReadinessCleanup: (() => void) | null = null;
let notifierID: string | number | null = null;
let startupData: StartupData | null = null;
let stopping = false;
const menuIDs: string[] = [];
const mainWindows = new Set<any>();
const itemChanges = new Map<number, { attachment: boolean }>();
let itemTimer: ReturnType<typeof setTimeout> | null = null;

function logError(error: unknown) {
  try { Zotero.logError(error instanceof Error ? error : new Error(String(error))); }
  catch { /* Shutdown and error reporting must remain independent. */ }
}

function actionError(error: unknown) {
  logError(error);
  const message = error instanceof Error ? error.message : String(error);
  try { Services.prompt.alert(Zotero.getMainWindow(), 'Smart Tags', message); }
  catch { /* The main window may have closed during an action. */ }
}

function personal(item: any) {
  return !!item && item.isRegularItem?.() && !item.deleted && item.libraryID === Zotero.Libraries.userLibraryID;
}

function mainWindowList(): any[] {
  return typeof Zotero.getMainWindows === 'function' ? Zotero.getMainWindows() : [Zotero.getMainWindow()].filter(Boolean);
}

async function analyzeScope(scope:'selected'|'collections') {
  await openManager();
  await workspace?.execute({type:'tag',payload:{scope}},{commandId:crypto.randomUUID()});
}

function registerMenus(data: StartupData) {
  const add = (menuID: string, target: string, menus: any[]) => {
    const registered = Zotero.MenuManager.registerMenu({ menuID, pluginID: data.id, target, menus });
    if (!registered) throw new Error(`Could not register Smart Tags menu: ${menuID}.`);
    menuIDs.push(registered);
  };
  add('smart-tags-tools', 'main/menubar/tools', [{
    menuType: 'menuitem', l10nID: 'smart-tags-open', icon: data.rootURI + 'content/icon.svg',
    onCommand: () => { void openManager().catch(actionError); },
  }]);
  add('smart-tags-items', 'main/library/item', [{
    menuType: 'menuitem', l10nID: 'smart-tags-analyze-selected',
    onShowing: (_event: unknown, context: any) => {
      const items = context.items || [];
      context.setVisible(items.length > 0 && items.some(personal));
      context.setEnabled(items.length > 0 && items.every(personal));
    },
    onCommand: () => { void analyzeScope('selected').catch(actionError); },
  }]);
  add('smart-tags-collections', 'main/library/collection', [{
    menuType: 'menuitem', l10nID: 'smart-tags-analyze-collections',
    onShowing: (_event: unknown, context: any) => {
      // Zotero 10 supports multiple collection rows. Singular getters now throw.
      const rows = context.collectionTreeRows || [];
      const collections = rows.filter((row: any) => row.isCollection?.());
      const visible = collections.length > 0 && collections.length === rows.length
        && collections.every((row: any) => row.ref?.libraryID === Zotero.Libraries.userLibraryID);
      context.setVisible(visible);
      context.setEnabled(visible);
    },
    onCommand: () => { void analyzeScope('collections').catch(actionError); },
  }]);
}

function scheduleItem(itemID: number, attachment: boolean) {
  if (stopping || !workspace || !host || host.mutating.has(itemID)) return;
  itemChanges.set(itemID,{attachment:attachment || !!itemChanges.get(itemID)?.attachment});
  if (itemTimer !== null) clearTimeout(itemTimer);
  itemTimer = setTimeout(() => {
    itemTimer = null;
    const changes=[...itemChanges].filter(([id])=>!host?.mutating.has(id)).map(([itemID,change])=>({itemID,...change}));
    itemChanges.clear();
    const app=workspace;
    if (!app || stopping || !changes.length) return;
    void app.notify(changes).catch(logError);
  },2000);
}

async function notifyItems(event: string, type: string, ids: (number | string)[], extraData: Record<string, {libraryID?: number}> = {}) {
  if (stopping || !workspace || !host) return;
  if (!['add', 'modify', 'remove', 'delete', 'trash', 'refresh'].includes(event)) return;
  const itemIDs = new Set<number>();
  for (const id of ids) {
    const value = Number(type === 'item-tag' ? String(id).split('-')[0] : id);
    if (Number.isSafeInteger(value) && value > 0) itemIDs.add(value);
  }
  for (const id of itemIDs) {
    if (stopping || !workspace || !host) return;
    const currentHost: ZoteroHost = host;
    if (currentHost.mutating.has(id)) continue;
    if (type === 'item' && extraData?.[id]?.libraryID !== undefined && extraData[id].libraryID !== Zotero.Libraries.userLibraryID) continue;
    let item: any;
    try { item = await Zotero.Items.getAsync(id); }
    catch (error) { logError(error); continue; }
    if (stopping || !workspace || host !== currentHost) return;
    if (!item) {
      if (type === 'item' && (event === 'delete' || event === 'trash')) scheduleItem(id, false);
      continue;
    }
    // Zotero refreshes the known parent when an attachment is erased.
    if (item.isRegularItem?.() && item.libraryID === Zotero.Libraries.userLibraryID) scheduleItem(id, type === 'item' && event === 'refresh');
    else if (type === 'item' && item.isAttachment?.() && item.parentID) {
      const parent = await Zotero.Items.getAsync(item.parentID).catch(() => null);
      if (personal(parent)) scheduleItem(parent.id, true);
    }
  }
}

export async function startup(data:StartupData) {
  if(workspace)return;
  stopping=false;startupData=data;
  if(Zotero.initializationPromise)await Zotero.initializationPromise;
  const directory=PathUtils.join(Services.dirsvc.get('ProfD',Ci.nsIFile).path,'smart-tags');
  await IOUtils.makeDirectory(directory,{ignoreExisting:true,createAncestors:true});
  try{
    workspace=createNativeWorkspace({directory,rootURI:data.rootURI,openManager,indexLibrary:data.indexLibrary});host=workspace.host.host;
    Zotero.ftl.addResourceIds([LOCALE]);for(const win of mainWindowList())onMainWindowLoad(win);registerMenus(data);
    notifierID=Zotero.Notifier.registerObserver({notify:notifyItems},['item','item-tag'],'smart-tags',50);
    const current=workspace;
    Zotero.SmartTags=Object.freeze({openManager,workspace:current,version:data.version,stateDirectory:directory,diagnostics:current.diagnostics});
    void current.ready.catch(logError);
  }catch(error){await shutdown().catch(logError);throw error;}
}

export async function openManager(options:ManagerUIOptions={}): Promise<Window | null> {
  if (!workspace || stopping) throw new Error('Smart Tags is not ready yet.');
  if (managerWindow && !managerWindow.closed) { managerUI?.navigate?.(options);managerWindow.focus(); return managerWindow; }
  const main = Zotero.getMainWindow();
  if (!main) throw new Error('Open Zotero’s library window before opening Smart Tags.');
  let initialWindow: Window | null = null;
  let finalWindow: Window | null = null;
  let mounted = false;
  let readinessStopped = false;
  let readyTimer: ReturnType<typeof setTimeout> | null = null;
  let attempts = 0;
  const diagnostic = (message: string) => {
    try { Zotero.debug?.(`[Smart Tags] Manager ${message}`, 3); } catch { /* Diagnostics must never prevent opening. */ }
  };
  const cleanupReadiness = () => {
    readinessStopped = true;
    if (readyTimer !== null) { clearTimeout(readyTimer); readyTimer = null; }
    try {
      initialWindow?.removeEventListener('DOMContentLoaded', attachFromEvent);
      initialWindow?.removeEventListener('load', attachFromEvent);
    } catch { /* The initial about:blank Window may already be gone. */ }
    if (managerReadinessCleanup === cleanupReadiness) managerReadinessCleanup = null;
  };
  const showFailure = (error: unknown) => {
    logError(error);
    diagnostic(`failed: ${error instanceof Error ? error.message : String(error)}`);
    try {
      const doc = (finalWindow || initialWindow)?.document;
      if (!doc) return;
      const app = doc.getElementById('app');
      if (!app) return;
      app.setAttribute('data-smart-tags-state', 'error');
      app.textContent = '';
      const box = doc.createElementNS(HTML, 'div');
      box.setAttribute('style', 'padding:35px;font:14px/1.5 system-ui,sans-serif;max-width:760px;');
      const title = doc.createElementNS(HTML, 'h2');
      title.textContent = 'Smart Tags could not finish opening';
      const details = doc.createElementNS(HTML, 'p');
      details.textContent = `${error instanceof Error ? error.message : String(error)} Close this window and reopen Smart Tags from Zotero’s Tools menu. If it continues, inspect Tools → Developer → Error Console.`;
      box.append(title, details);
      app.append(box);
    } catch (renderError) { logError(renderError); }
  };
  const attach = (candidate?: Window | null) => {
    if (mounted || readinessStopped) return;
    if (!workspace || stopping) { cleanupReadiness(); return; }
    const target = candidate || finalWindow || initialWindow;
    if (!target) return;
    let foundApp = false;
    try {
      if (target.closed) { cleanupReadiness(); return; }
      const doc = target.document;
      const app = doc?.getElementById('app');
      if (attempts < 3 || attempts % 20 === 0) diagnostic(`readyState=${doc?.readyState || 'unavailable'}, uri=${doc?.documentURI || 'unavailable'}, app=${!!app}, attempt=${attempts}`);
      if (!app) return;
      foundApp = true;
      finalWindow = target;
      managerWindow = target;
      mounted = true;
      cleanupReadiness();
      app.setAttribute('data-smart-tags-state', 'mounting');
      diagnostic('mount begin');
      managerUI = mountManager(target, managerAPI(main),options);
      diagnostic('mount attached; awaiting local snapshot');
    } catch (error) {
      if (!foundApp && !finalWindow) { diagnostic('initial window unavailable; waiting for final document loader'); return; }
      mounted = true; cleanupReadiness(); showFailure(error);
    }
  };
  const attachFromEvent = () => attach();
  const poll = () => {
    readyTimer = null;
    attempts++;
    attach();
    if (mounted || stopping || readinessStopped) return;
    if (attempts >= 200) { cleanupReadiness(); showFailure(new Error('The manager document did not become ready within 20 seconds.')); return; }
    readyTimer = setTimeout(poll, 100);
  };
  managerReadinessCleanup?.();
  managerReadinessCleanup = cleanupReadiness;
  // The loader runs inside the final XHTML document. about:blank listeners/timers
  // belong to an initial Window and can disappear during native navigation.
  const bridge = {
    onReady(child: Window) {
      diagnostic('final document loader ready');
      finalWindow = child;
      attach(child);
    },
    onClosed(child: Window) {
      if (finalWindow !== child) return;
      cleanupReadiness();
      if (managerWindow === child) {
        managerUI?.destroy(); managerUI = null; managerWindow = null;
      }
    },
    onFailure(error: unknown) { showFailure(error); },
  };
  initialWindow = main.openDialog(`${MANAGER_URL}?v=${encodeURIComponent(startupData?.version || 'dev')}`, 'zotero-smart-tags-manager', 'chrome,dialog=no,resizable,centerscreen,width=1180,height=820', bridge) as Window;
  if (!initialWindow) { cleanupReadiness(); throw new Error('Zotero could not open the Smart Tags manager.'); }
  managerWindow = finalWindow || initialWindow;
  if (!mounted) {
    initialWindow.addEventListener('DOMContentLoaded', attachFromEvent);
    initialWindow.addEventListener('load', attachFromEvent);
  }
  // Never attach an unload listener to the initial about:blank Window.
  attach();
  if (!mounted) readyTimer = setTimeout(poll, 100);
  managerWindow.focus();
  return managerWindow;
}

function managerAPI(_main:unknown):Workspace {
  const current=workspace!;
  return {
    execute:(command,options)=>current.execute(command,options),
    watch:(query,receive,options)=>current.watch(query,event=>receive(event.model?{...event,model:{...event.model,pluginVersion:startupData?.version}}:event),options),
    close:reason=>current.close(reason),
  };
}

export function onMainWindowLoad(win: any) {
  if (!win || mainWindows.has(win) || stopping) return;
  mainWindows.add(win);
  try {
    if (win.MozXULElement?.insertFTLIfNeeded) win.MozXULElement.insertFTLIfNeeded(LOCALE);
    else if (win.document?.l10n) win.document.l10n.addResourceIds([LOCALE]);
  } catch (error) { logError(error); }
}

export function onMainWindowUnload(win: any) {
  if (!win) return;
  mainWindows.delete(win);
  try {
    for (const link of win.document?.querySelectorAll(`link[rel="localization"][href="${LOCALE}"]`) || []) link.remove();
    win.document?.l10n?.removeResourceIds([LOCALE]);
  } catch { /* A closing document can no longer accept localization changes. */ }
}

export async function shutdown() {
  stopping = true;
  if(itemTimer !== null)clearTimeout(itemTimer);itemTimer=null;itemChanges.clear();
  if (notifierID !== null) { try { Zotero.Notifier.unregisterObserver(notifierID); } catch (error) { logError(error); } notifierID = null; }
  managerReadinessCleanup?.(); managerReadinessCleanup = null;
  managerUI?.destroy(); managerUI = null;
  if (managerWindow && !managerWindow.closed) managerWindow.close();
  managerWindow = null;
  for (const id of menuIDs.splice(0)) { try { Zotero.MenuManager.unregisterMenu(id); } catch (error) { logError(error); } }
  for (const win of [...mainWindows]) onMainWindowUnload(win);
  try { Zotero.ftl.removeResourceIds([LOCALE]); } catch (error) { logError(error); }
  const current=workspace;workspace=null;host=null;
  try{await current?.close('disable');}
  finally{if(Zotero.SmartTags?.workspace===current)delete Zotero.SmartTags;startupData=null;}
}
