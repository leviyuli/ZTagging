# Upgrading to Smart Tags 0.8.1

## Version 0.8.1

State remains **schema 7**. Install the update over the existing extension. If a run is stuck on **Switching to faster build…**, click **Retry faster build** or **Resume**. The pending switch continues; it does not restart the older chooser or reset saved replies, correction counters, or spending.

An attachment notification could previously remove cached analysis even when the paper's metadata and PDF content were unchanged. The switch now verifies current inputs and quotations locally before restoring a missing factual record from its immutable snapshot. This recovery makes no extraction request and does not change native library data. Unchanged attachment notifications also retain usable facts.

If the inputs changed or a required PDF cannot be checked locally, the run stays paused with a paper-recovery message. Open **Papers that need attention**, inspect or recheck the PDF, or explicitly retry that paper's analysis, then retry the faster build. Existing analysis for other papers remains available.

## Version 0.8.0

Install the update over the existing extension. Before writing **schema 7**, Smart Tags saves an immutable exact-byte **state.json.pre-v7.json** backup. An occupied filename with different bytes is preserved and a numbered suffix is used. Backup or migration-write failure stops without substituting an older valid `.bak`; older applications refuse to overwrite schema-7 state.

Schema-6 migration changes only the schema field. It preserves cached factual extraction, quotations and provenance, source identities, selected snapshots, completed jobs, pending proposals, edits and answers, raw responses, old planner-3 checkpoints, journals, settings, credentials, and spent budget. Migration performs no provider request or native-library change. Factual extraction, terminology, and source-validation policy 3 remain unchanged.

New builds use **representative planner 4**. For an unfinished older build whose paper reading is complete, choose **Use faster build** in Activity or the run's progress bar. This explicit action sets a preferred target of **60** and waits for active requests to settle before changing the saved schedule. It retains old work and responses in history, reuses valid facts and compatible exact-source decisions, and preserves researcher edits and exclusions. Installation or ordinary Resume does not silently convert an existing planner-3 build.

Representative verification checks up to **three different example papers per tag**, using requests of at most **64 tag–source pairs and 90 KB**, with up to two independent requests in flight. Smaller output limits can reduce batch size. Valid results persist immediately; one bounded repair round checks unresolved pairs without repeating accepted ones. Authentication, quota, connection, permission, and budget failures still pause with the selected provider unchanged.

Review counts describe **verified example papers**, not total matching library papers. Unsampled findings remain unexamined and cannot authorize outside-vocabulary or no_tag decisions. Policy-3 proofs still bind each accepted tag/source pair to its snapshot and fingerprints. Unsupported generated topics may be deferred; DIY and protected definitions are retained. Ambiguous examples may be omitted when another checked example grounds the same concept, while unresolved concept meanings remain researcher questions.

A local simulation using a copied 744-paper build retained its 60 frozen tags and scheduled 180 example pairs in three requests, the largest 78,839 bytes; 5,832 findings remained unexamined. It used synthetic replies with no new chooser, extraction, native writes, or live provider calls. These figures demonstrate the saved schedule, not scientific accuracy or a completion-time guarantee.

**Apply tag list** saves definitions only. Choose the assignment group separately in **Assign & automate**, review the paper suggestions, and confirm their native Apply with undo. Upgrading or switching build planners does not enable incoming assignment or satisfy its pilot gate.

## Version 0.7.1

State remains schema 6. Install the update without uninstalling, then click **Resume** or **Retry this step** on a paused tag-selection run. Before requesting another reply, Smart Tags rechecks the last complete saved reply locally. Successful local recovery retains the previous raw replies, repair counters, spending, selected source snapshot, and completed paper analysis. Loading the extension does not make a provider request or write native library data.

Existing DIY definitions stay unchanged. Generated aliases that claim an existing DIY name are withheld; this does not merge a broad generated topic into the narrower DIY topic. A failed local recheck does not reset automatic allowances or consume a paid request.

Source checks use a smaller transport view of each frozen definition: identity, name, full meaning, category, nonempty matching guidance, and subtype context. Search aliases and administrative settings stay local. The original definitions, meaning fingerprints, source IDs, and full validated source text remain unchanged. Completed batches retain their identities; the update does not restart them merely to repack requests.

## Version 0.7.0

This release upgrades local state to **schema 6**, after saving an immutable exact-byte **state.json.pre-v6.json** backup. An occupied filename with different content receives a numbered suffix. Backup or migration-write failure stops without replacing a valid generation from an older `.bak`. Migration performs no model request or native library change.

Cached paper facts, completed jobs, quotations, source and registry IDs, selected snapshots, historical confirmations, definitions, decisions, journals, settings, credential references, and spent budget are preserved. The factual extractor and terminology versions remain unchanged. Older reviewable proposals retain their historical validation behavior.

For an unfinished build, update normally and click **Resume**. Smart Tags reuses its selected facts and valid snapshot, retains the old consolidation checkpoint as audit data, and starts global selection and source checking. It does not continue recursive reduction or reread unchanged papers through the model. Changed paper information still refreshes only affected facts.

New work persists its shortlist, candidate IDs, frozen definitions, source decisions, task states, raw replies, and dispatched counters. Source-validation policy 3 requires an explicit current decision for each covered source. Old confirmations cannot approve new unchecked sources. Ordinary presentation changes preserve compatible proofs; meaning changes require checks of the affected links.

Two independent mapping requests may run at once. Budget reservations and result application are serialized; interrupted or usage-less requests retain their reservations. A complete reply saved before interruption can be replayed without another request. Resume never resets correction allowances. Retry this step starts an explicit retry of failed technical work while retaining prior attempts, completed checks, and spending.

Tag selection favors the largest area in the chosen build group. The initial target is 60 core tags, plus necessary parent closure when needed. Extend keeps all applied definitions; its automatic addition allowance is the greater of the remaining preferred slots or one quarter of the preferred count (15 additions for an existing 60-tag list), plus required parents. This guides automatic selection and is not an approval limit. Deferred topics and their original evidence remain retained, and manually added DIY topics stay available.

## Version 0.6.0

The sidebar now follows **Connect AI → Build tags → Review & clean up → Assign & automate**, with the applied list under **Tag library**. Apply tag list saves definitions without immediately analyzing the build papers for assignment. Choose a separate assignment group and start its suggestions explicitly. Native paper tags still require a reviewed batch Apply.

State remains schema 5, with optional workflow choices and an immutable baseline for new-field builds. Cached factual extraction, source identities, historical snapshots and confirmations, credentials, settings, completed work, and native data remain intact. Loading the update performs no provider request. Existing paused builds keep their original mode; updating does not reinterpret an old proposal as an extension.

New builds default to adding tags when an applied list exists. The current applied definitions are retained while incoming suggestions are checked against the newly selected papers. Old papers are not silently added to the new evidence snapshot. Full replacement remains an explicit option. Build and assignment group choices are kept independently; the first assignment group defaults to the whole personal library.

The assignment-pilot gate is unchanged: use Run assignment pilot, review its suggestions, and mark the pilot reviewed before enabling incoming-paper automation. Applying a different core tag list resets that gate and turns automatic assignment off. DIY creation alone does not reset it.

Earlier evidence remains in separate build records when you extend the list. Restoring a previous list that spans several builds requires rebuilding a proposal from the retained paper facts; the extension explains this rather than mixing source identities from different snapshots. Native assignment undo remains available through History.

## Version 0.5.3

Install the update through Zotero without uninstalling the existing extension. If a build is already paused, click **Resume** once after updating. Routine reply repair then continues automatically. Saved completed parts, original replies, cached extraction, selected evidence, settings, credentials, manual choices, and spent budget are retained. Loading the update makes no provider request or native library change.

State remains schema 5 and consolidation remains protocol 2. Optional queue fields record dispatched organization requests, fresh-reply allowance, split depth, and superseded portions. Completed old portions are not repartitioned or resent. Unstarted oversized portions can be divided before dispatch; replaced parent portions retain their replies and are marked complete with no output, while active child portions carry the remaining work. Short transport references resolve against each portion's exact persistent input IDs; original evidence identities, wording, and historical proofs are unchanged. No factual-extractor or terminology-policy version changes are required.

An existing complete failed reply is rechecked locally before another request. Each portion can receive one correction per generation and at most one automatic fresh generation along its split lineage. Splits stop at a bounded size/depth, and each build allows at most 512 dispatched organization requests. Budget rejection before dispatch does not consume an attempt. Counters survive restart and ordinary Resume. The three-request scientific-preparation allowance remains separate. Changing provider or starting another build still requires an explicit user choice; spent budget is not reset by automatic recovery.

## Version 0.5.2

This is an interface-only patch. State schema remains 5, with no migration, reanalysis, provider call, native tag write, or reset of saved work during upgrading. Attention actions have moved into compact menus; their controller behavior, review steps, and undo records are unchanged.

## Version 0.5.1

This patch keeps state schema 5. Existing schema-5 profiles retain their current generation, cached extraction, evidence wording and IDs, settings, credentials, manual choices, and history. New dismissal and exclusion-preview fields are optional; no extraction or provider request runs during loading. Profiles upgrading from an earlier schema still use the exact-byte pre-v5 backup process below.

Saved failed consolidation replies are rechecked locally when you Resume. Routine relationship recovery changes the proposed organization, not the original paper evidence or native tags. Correction attempts and replies are retained with the current part; explicit retry generations preserve earlier attempt history and spent budget. Incomplete provider replies remain diagnostic only.

The built-in no_tag definition is supplied locally. Native no_tag assignments mean an item is excluded until you choose Include again or remove the marker. Existing reserved-name definitions and their historical IDs are preserved, and their remembered choices remain protected. Exclude/Include changes use the normal native-tag journal with stale checks and undo. Dismissals acknowledge a condition without marking its underlying information gap resolved.

## Upgrading an older state to schema 5

Install the new XPI over the existing extension and open **Tools → Smart Tags…**. Startup upgrades local application state to **schema 5**. Consolidation continues to use ID-based protocol 2; terminology normalization and factual extraction versions are unchanged by this migration. Migration performs no model requests and changes no native Zotero tags, metadata, collections, columns, or credentials.

Schema-4 source evidence, pending proposals, human choices, IDs, completed jobs, raw queue responses, settings, budgets, and history are copied intact. The old derived cleanup preview is cleared. Reopen **Existing tags → Read library tags** to create a current comparison against the applied vocabulary.

## Continuing an existing review

Open **Review & clean up** for a saved proposal, or **Activity → Resume** for an interrupted build. The extension retains selected evidence, saved edits, human confirmations, and completed paper analysis. It runs local preparation checks first when a proposal is available. If more scientific checking is needed, choose **Resume checks**; if a preparation run cannot finish, **Try again** starts another bounded attempt. You do not need to discard the review or repeat unchanged factual extraction.

Large builds now organize validated concepts in bounded portions before producing one global proposal. Saved completed portions and raw responses are retained. **Reading papers** reaching the selected count means extraction is complete; **Organizing tags** and **Checking tag meanings** still precede **Ready for review**. Resume continues available work, with changed metadata or PDF evidence refreshing only affected papers.

The new preparation stage can make **up to three additional requests** after the initial tag-list draft, using your explicitly selected provider and model. These requests use the existing budget controls. The old one-correction checkpoint remains in history and does not consume the new preparation allowance. A dispatched request counts even if it fails or is interrupted; a budget rejection before dispatch does not. Pause, restart, and ordinary Resume preserve the counter and saved responses. An explicit retry retains prior preparation replies and spent-budget history.

**Questions** contains choices that the available scientific context cannot settle. Existing edits, DIY names, and human choices remain protected. The preferred number of core tags is **60**, with distinct concepts allowed to remain separate above that number.

When ready, **Apply tag list** saves the vocabulary. In 0.6.0, continue to **Assign & automate**, choose the assignment group, and start suggestions explicitly. Inspect those in **Paper suggestions**, then confirm a separate batch Apply to write native tags. That batch has an undo record in **Activity**. Preparing a list, answering questions, and applying the list do not enable unattended assignment. Review the tagging pilot before enabling automation.

## Backups and retained evidence

Before writing schema 5, the extension creates an immutable, exact-byte **state.json.pre-v5.json** backup in the profile's `smart-tags` directory. A different existing backup is kept and a numbered filename is used. Earlier pre-v2/pre-v3/pre-v4 backups remain intact. Backup, migration, or migration-write failures stop without substituting an older valid `.bak` generation. A state file from a newer schema is refused, including attempted downgrade writes.

Factual source wording, quotations, fingerprints, extractor version, provider/model provenance, and existing IDs are retained. Completed jobs remain reusable when their evidence is unchanged. Settings, credentials, previously spent budget, decisions, locks, assignment ownership, native snapshots, and undo journals are preserved. Changed metadata or newly readable PDFs refresh affected papers. Private profile backups contain library metadata and should stay out of public artifacts.

Schema-3 pending reviews keep their evidence snapshots, candidate allocations, raw replies, and historical human proofs. Obsolete coverage entries for already removed candidates are pruned from active derived coverage; the original source evidence and review history remain retained. New source-level scientific judgements and researcher answers are stored separately from historical confirmation records.

## Paper recovery and reviewed native changes

Evidence notices now lead to **Activity → Papers that need attention**. Validated concepts remain usable when additional context was requested. The paper view distinguishes missing information from failed analysis; dismissal does not claim that evidence has been repaired.

Use **Find metadata**, review the identifier-confirmed additions, and choose **Apply metadata** to fill empty bibliographic fields or an empty creator list. **Recheck PDF** explicitly checks local files and retries local indexing; it does not download files or run OCR. **Retry analysis** and **Retry selected** queue requested work behind an ongoing library build. **Skip for this build** keeps the native item and its existing tags intact.

Metadata repairs have exact before/after journals and preserve superseded factual extraction in local history. Apply, recovery, and undo invalidate affected derived analysis. **Existing tags** changes and DIY-definition creation also have reviewed history records. Undo restores only the recorded changes and refuses conflicting later edits; partial or externally changed native batches remain marked for review rather than overwriting current data.

Creating DIY definitions or confirming equivalent approved aliases preserves the current core pilot. Applying a different core vocabulary still requires reviewing its tagging pilot before unattended assignment. Provider selection, encrypted credentials, and automatic-assignment preferences are retained; recovery does not switch providers or enable automation.

## Safe legacy-draft cleanup

For upgrades from schema 3 or earlier, the existing legacy cleanup removes unused generated drafts from active extension definitions only when an original baseline proves their fields are unchanged. Custom, approved, edited, manually referenced, historically referenced, and current-proposal definitions are kept, together with definitions needed by their relationships. Unknown origins or a missing baseline cause definitions to be retained. Upgrading an existing schema-4 state does not rerun that cleanup or alter its current proposal.

This is permanent cleanup of eligible extension draft records, backed by the standard exact-byte migration backup. It creates no additional legacy archive and removes no native paper tags. The current review and its stable IDs remain available. Regular vocabulary history and tag-change undo continue to work.

## Notices and older installations

**Activity** keeps actionable notices with affected-paper links and persistent dismissal. Successful reevaluation resolves only the corresponding paper and processing phase. Unfamiliar-topic notices clear when fresh assignment analysis no longer finds that condition; completed merge reviews belong in history. A later successful request does not establish the missing usage of an earlier request or confirm an earlier remote revocation. Brief success confirmations disappear after the action.

From schema 1 or 2, the earlier local evidence-identity and preparation upgrades run before schema 5. They add local IDs without repeating unchanged factual extraction, and invalidate incompatible name-based consolidation checkpoints and proposals. Resume the saved work or prepare tags again for the intended scope. Legacy support links are converted only through uniquely validated matches; ambiguous or scientifically uncertain links remain unresolved. Old warning strings remain historical, unverified notices without invented paper associations or dates.

Older definition exports remain importable. Private proposal/evidence exports retain their source and vocabulary checks. Normal definition export stays separate from exports containing paper wording and quotations.

The account/workspace switch introduced in 0.4.1 is available under **Connect AI → Use another account or workspace**. It preserves saved accounts and paper analysis while starting a fresh ChatGPT connection when needed.
